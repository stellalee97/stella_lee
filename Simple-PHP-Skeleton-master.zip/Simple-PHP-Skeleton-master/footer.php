
	<footer class="site-footer">
	
	</footer>

	<!-- CDN JS Dependencies -->
	<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script> <!-- Adding Jquery for you -->
	<script src="http://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script> <!-- Adding Jquery UI for you -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script> <!-- Adding PrefixFree for you -->

	<!-- Local JS -->
	<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/JS/main.js"></script> <!-- Your local Javascript file -->

	<!-- CDN CSS Dependencies -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css"> <!-- Adding Normalize for you -->

	<!-- Local CSS -->
	<link rel="stylesheet" href="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/css/main.css"> <!-- Adding Normalize for you -->

	</body><!-- visible content should end -->
</html>
