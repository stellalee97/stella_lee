<? include("header.php") ?>

<p>It's a 404...</p> <!-- This page gets rendered if you go to a url you weren't suppose to -->

<? include("footer.php") ?>

