<? include("header.php") ?>

<div class="main">

</div>

<? include("footer.php") ?>

